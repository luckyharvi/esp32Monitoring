<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Version 1.0.0
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024-2025 <a href="https://adminluckyharvi.org">Adminluckyharvi.org</a>.</strong> All rights reserved.
</footer>